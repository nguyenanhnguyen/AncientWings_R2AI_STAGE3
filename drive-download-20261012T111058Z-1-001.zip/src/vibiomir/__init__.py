"""ViBioMIR project code."""
