"""A2→A3 bridge: turn whatever a crawler wrote into the one corpus file the pipeline reads.

Crawlers in this project write different shapes: the per-id run directory (`records/<id>.json`
plus raw gzip) and the team crawler's JSON/Parquet exports with a `status` column. This step reads
any of them, keeps one row per source id, removes rows that are not the article the id points to,
and writes `work/corpus/corpus.parquet` with a fixed schema. Every later block reads only that file.

What is removed, and why each is not just a quality nuisance:

    fetch_failed       No page was fetched; there is no text to search.
    empty_text         Fetched, but extraction produced nothing.
    homepage_redirect  The URL redirected to the site's root. The stored text is the homepage, not
                       the article. In the first crawl batch this was 2.236 ids, 2.230 of them the
                       same "Trang chủ" text; left in, they would match many queries and crowd out
                       real articles in every submission.
    template_text      More than `--max-duplicates` ids share one text. A real article republished
                       a few times is kept; hundreds of ids with identical text are an error page or
                       a template.
    quality_rejected   The crawler's own QC rejected it (error page, anti-bot challenge).

Rows the crawler only marked `review` are kept, with their flags. F2 weights recall four times
precision, so a short or slightly noisy article is still worth having in the index.

Nothing here rewrites text beyond the light normalisation every block already applies, so the
chunk spans cut from this corpus are still spans of the source.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit

import pyarrow as pa

from ..common import storage
from ..common.console import emit
from ..common.schema import detect_language, document_text

CORPUS_SCHEMA = pa.schema([
    ('id', pa.int64()),
    ('url', pa.string()),
    ('final_url', pa.string()),
    ('domain', pa.string()),
    ('title', pa.string()),
    ('text', pa.string()),
    ('lang', pa.string()),
    ('status', pa.string()),
    ('quality_status', pa.string()),
    ('quality_flags', pa.list_(pa.string())),
    ('published_at', pa.string()),
    ('extractor', pa.string()),
    ('char_count', pa.int64()),
    ('text_sha256', pa.string()),
    ('raw_path', pa.string()),
    ('raw_sha256', pa.string()),
    ('duplicate_doc_ids', pa.list_(pa.int64())),
    ('source', pa.string()),
])

OK_STATUSES = {'ok', 'extracted'}
_LANG_HINTS = {'vi_hint': 'vi', 'zh_hint': 'zh', 'vi': 'vi', 'zh': 'zh', 'en': 'en'}


# --- Reading each crawler's shape ---

def _run_directory_rows(path, limit=None):
    """The per-id run layout: <run>/records/<id>.json, raw paths relative to <run>."""
    files = sorted((path / 'records').glob('*.json'), key=lambda item: int(item.stem))
    if limit:
        files = files[:limit]
    for file in files:
        try:
            row = json.loads(file.read_text(encoding='utf-8'))
        except (OSError, ValueError) as error:
            yield {'id': int(file.stem), '_unreadable': str(error)[:200]}
            continue
        if row.get('raw_path'):
            row['raw_path'] = str((path / row['raw_path']).as_posix())
        yield row


def read_source(path, limit=None):
    """Rows from a run directory or an exported file, in increasing id order when known."""
    path = Path(path)
    if path.is_dir():
        if not (path / 'records').is_dir():
            raise ValueError(f'{path} is a directory without records/; pass the run directory '
                             'or an exported .parquet/.json/.jsonl file.')
        yield from _run_directory_rows(path, limit)
        return
    rows = storage.read_rows(path)
    rows.sort(key=lambda row: int(row['id']))
    yield from (rows[:limit] if limit else rows)


# --- Turning one source row into one corpus row, or a reason it is dropped ---

def _is_homepage_redirect(url, final_url):
    if not url or not final_url:
        return False
    try:
        source, final = urlsplit(url), urlsplit(final_url)
    except ValueError:
        return False
    return final.path in ('', '/') and source.path not in ('', '/') and not final.query


def _language(row, text):
    for key in ('lang', 'language_hint'):
        mapped = _LANG_HINTS.get(row.get(key) or '')
        if mapped:
            return mapped
    return detect_language(text)


def normalise_row(row, source, text_field=None):
    """-> (corpus row, None) when kept, or (None, drop reason)."""
    if row.get('_unreadable'):
        return None, 'unreadable_record'
    status = row.get('status') or 'ok'
    if status not in OK_STATUSES:
        return None, f'fetch_failed:{status}'
    if row.get('quality_status') == 'rejected':
        return None, 'quality_rejected'
    url = row.get('url') or ''
    final_url = row.get('final_url') or url
    if _is_homepage_redirect(url, final_url):
        return None, 'homepage_redirect'
    text = document_text(row, text_field)
    if not text.strip():
        return None, 'empty_text'
    flags = [flag for flag in (row.get('quality_flags') or []) if flag != 'redirect_review']
    return {
        'id': int(row['id']),
        'url': url,
        'final_url': final_url,
        'domain': row.get('domain') or (urlsplit(url).hostname or ''),
        'title': (row.get('title') or '').strip(),
        'text': text,
        'lang': _language(row, text),
        'status': 'ok',
        'quality_status': row.get('quality_status') or 'accepted',
        'quality_flags': flags,
        'published_at': None if row.get('published_at') is None else str(row['published_at']),
        'extractor': row.get('extractor') or '',
        'char_count': len(text),
        'text_sha256': storage.sha256_text(text),
        'raw_path': row.get('raw_path') or '',
        'raw_sha256': row.get('raw_sha256') or '',
        'duplicate_doc_ids': [],
        'source': str(source),
    }, None


def build(args):
    kept, dropped = {}, []
    seen = set()
    remaining = args.limit
    for source in args.source:
        for row in read_source(source, limit=remaining):
            doc_id = int(row['id'])
            if doc_id in seen:
                # Several shards may carry the same id; the first source given wins.
                continue
            seen.add(doc_id)
            record, reason = normalise_row(row, source, args.text_field)
            if record is None:
                dropped.append({'id': doc_id, 'reason': reason, 'url': row.get('url')})
            elif args.drop_review and record['quality_status'] == 'review':
                dropped.append({'id': doc_id, 'reason': 'quality_review', 'url': record['url']})
            elif record['char_count'] < args.min_chars:
                dropped.append({'id': doc_id, 'reason': 'below_min_chars', 'url': record['url']})
            else:
                kept[doc_id] = record
        if args.limit:
            remaining = args.limit - len(seen)
            if remaining <= 0:
                break

    groups = {}
    for doc_id, record in kept.items():
        groups.setdefault(record['text_sha256'], []).append(doc_id)
    for members in groups.values():
        if len(members) > args.max_duplicates:
            for doc_id in members:
                record = kept.pop(doc_id)
                dropped.append({'id': doc_id, 'reason': 'template_text', 'url': record['url']})
        elif len(members) > 1:
            # Every id stays: any of them may be the labelled one. The group is only noted.
            for doc_id in members:
                kept[doc_id]['duplicate_doc_ids'] = [other for other in members if other != doc_id]

    rows = [kept[doc_id] for doc_id in sorted(kept)]
    if not rows:
        raise ValueError('No usable documents; see the drop reasons above.')
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    corpus = storage.write_parquet(out / 'corpus.parquet', rows, schema=CORPUS_SCHEMA)
    storage.write_jsonl(out / 'dropped.jsonl', sorted(dropped, key=lambda item: item['id']))
    lengths = sorted(row['char_count'] for row in rows)
    summary = {
        'rows_read': len(seen),
        'documents_kept': len(rows),
        'documents_dropped': len(dropped),
        'drop_reasons': dict(Counter(item['reason'] for item in dropped).most_common()),
        'quality_status': dict(Counter(row['quality_status'] for row in rows)),
        'languages': dict(Counter(row['lang'] for row in rows)),
        'domains': dict(Counter(row['domain'] for row in rows).most_common()),
        'duplicate_groups_kept': sum(1 for members in groups.values()
                                     if 1 < len(members) <= args.max_duplicates),
        'chars_median': lengths[len(lengths) // 2],
        'chars_p95': lengths[int(len(lengths) * 0.95)],
        'id_min': rows[0]['id'], 'id_max': rows[-1]['id'],
        'options': {'limit': args.limit, 'max_duplicates': args.max_duplicates,
                    'min_chars': args.min_chars, 'drop_review': args.drop_review,
                    'text_field': args.text_field},
        'sources': [str(source) for source in args.source],
    }
    storage.write_manifest(out / 'prepare_manifest.json', summary, files=[corpus])
    emit(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('--source', nargs='+', required=True,
                        help='Crawl run directories (with records/) or exported '
                             '.parquet/.json/.jsonl files. Earlier sources win on shared ids.')
    parser.add_argument('--out', default='work/corpus')
    parser.add_argument('--limit', type=int, default=None,
                        help='Read at most this many source rows, lowest ids first.')
    parser.add_argument('--max-duplicates', type=int, default=20,
                        help='More ids than this sharing one text are treated as a template.')
    parser.add_argument('--min-chars', type=int, default=0,
                        help='Drop documents shorter than this. Default keeps every non-empty one.')
    parser.add_argument('--drop-review', action='store_true',
                        help='Also drop rows the crawler marked for review.')
    parser.add_argument('--text-field', default=None,
                        help='Column holding the body. Default: text, content or body, else a '
                             'question plus answers.')
    args = parser.parse_args()
    if args.limit is not None and args.limit < 1:
        parser.error('--limit must be positive')
    build(args)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
